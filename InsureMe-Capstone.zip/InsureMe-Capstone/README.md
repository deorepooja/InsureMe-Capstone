# InsureMe Capstone

## DevOps Workflow using Jenkins, Docker, K8s, and AWS